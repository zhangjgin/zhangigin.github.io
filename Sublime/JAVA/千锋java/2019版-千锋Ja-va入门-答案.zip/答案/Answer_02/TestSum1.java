package chp3;

public class TestSum1 {
	public static void main(String[] args) {
		int sum = 0;
		for(int i = 1; i<=100; i++){
			sum System.out.println(a);+= i;
		}
		System.out.println(sum);
	}
}
