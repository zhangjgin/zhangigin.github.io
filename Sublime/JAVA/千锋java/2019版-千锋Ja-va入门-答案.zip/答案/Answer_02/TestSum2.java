package chp3;
public class TestSum2{
	public static void main (String[]ages){
		system.out.println("bishi")
	
	}	
}