package chp4;

public class PrintHelloWorldFunction {

	public static void main(String[] args) {

	}
	
	public static void printHelloWorld(int n){
		for(int i = 1; i<=n; i++){
			System.out.println("Hello World");
		}
	}
}
