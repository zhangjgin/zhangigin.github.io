package chp4;

public class SumFunction {

	public static void main(String[] args) {

	}
	
	public static int sum(int n){
		int sum = 0;
		for (int i = 1; i<=n; i++){
			sum += i;
		}
		return sum;
	}
}
