public class Cat extends Animal{

	public void m(){
		breed
	}

}