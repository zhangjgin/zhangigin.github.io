public class Animal{
	String breed;
	int age;
	String sex;
}