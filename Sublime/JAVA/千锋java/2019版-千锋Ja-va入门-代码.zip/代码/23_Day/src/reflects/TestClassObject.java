package reflects;

public class TestClassObject {

	public static void main(String[] args) {

//		Clsas c = new Class();
//		
//		c.packageName = "reflects.Student";
//		c.className = "Student";
//		c.superClassName = "java.lang.Object";
//		c.fields = new Field[3]{"String name","int age","String sex"};
//		c.methods = new Method[2]{"public void study(){}","public int exam(){ return 0; }"};
//		c.constractors = new Constractors[2]{"",""};
		
//		Student s = new Student();//��Ķ���
//		
//		Class c = s.getClass();//�����      ����Ķ����ģ��
//		
//		System.out.println(.toString());
		
	}

}

//Student.class
//Teacher.class
//Dog.class
//Runnable.class
//Server.class


//class Student{
//	String name;
//	int age;
//	String sex;
//	
//	public Student(){}
//	public Student(String name, int age, String sex) {
//		super();
//		this.name = name;
//		this.age = age;
//		this.sex = sex;
//	}
//
//	public void study(){}
//	public int exam(){ return 0; }
//}