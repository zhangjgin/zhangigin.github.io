package factory;

public class Keyboard implements USB {
	@Override
	public void service() {
		System.out.println("�û�...");
	}
}
