package encapsulate;
/*
public class TestEncapsulation {

	public static void main(String[] args) {
		
		byte b1 = 11;//10
		
		System.out.println((double)11);
		
		System.out.println(b1);
		
		Byte b2 = new Byte(10); //new Byte(12);
		
		System.out.println(b2);
		
		Object o = new Byte(20);
		
		method(new Byte(30));
		
		System.out.println(Byte.MAX_VALUE);
		
		
		double d = b2.doubleValue();
		
	}
	
	public static Byte method(Object o){
		return null;
	}

}


class Byte{
	private byte value;
	
	public static final byte MAX_VALUE = 127;
	public static final byte MIN_VALUE = -128;
	
	
	public Byte(byte value){
		this.value = value;
	}
	
	public Byte(int value){
		this.value = (byte)value;
	}

	@Override
	public String toString() {
		return this.value + "";
	}
	
	public double doubleValue(){
		return (double)this.value;
	}
	
}
*/