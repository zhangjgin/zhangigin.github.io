public class TestUp{
	public static void main(String[] args){
		
		double num1 = 1 + 5.2;
		
		float num2 = 5 + 3.5F;
		
		
		long num3 = 3L + 123;
		
		
		int num4 = 5 + 8;
		
		
		short s = 5;
		byte e = 3;
		
		int num5 = s + e;
		
		
		String str = "abc";
		
		String result = num2 + num3 + str ;
		
		System.out.println(result);
		
	}
}