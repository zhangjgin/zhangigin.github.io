package callback;

public class MyCheckPrime implements CheckPrime {

	public boolean isPrime(){
		return true;
	}
}
