package callback;

public interface CheckPrime {

	public boolean isPrime();
}
