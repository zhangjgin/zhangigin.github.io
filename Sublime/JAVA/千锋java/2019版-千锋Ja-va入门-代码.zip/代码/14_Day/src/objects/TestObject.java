package objects;

public class TestObject {

	public static void main(String[] args) {

		// Object o = new Car();

		//method(new Student());

	}

	public static void method(Object obj) {

	}

	public static void goHome(Object obj) {

	}

	public static Object buyVehicle(int n) {
		return null;
	}

}
/*
class Dog {
}

class Car {
}

class Student {
}
*/