public class B{
	public static void main(String[] args){
		System.out.print("HelloEveryone");
	}
}

public class A{
	public static void main(String[] args){
		System.out.println("My name's Second");
	}
}