public class TestDefaultValues{
	public static void main(String[] args){
		
		int[] intValues = new int[4];
		
		System.out.println(intValues[0]);
		
		double[] doubleValues = new double[4];
		
		System.out.println(doubleValues[0]);
		
		boolean[] boolValues = new boolean[4];
		
		System.out.println(boolValues[0]);
	
		String[] stringValues = new String[4];
		
		System.out.println(stringValues[0]);
		
		char[] charValues = new char[4];
		
		System.out.println(charValues[0]);
	}
}