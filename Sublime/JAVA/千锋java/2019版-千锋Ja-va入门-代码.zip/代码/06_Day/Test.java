public class Test{
	public static void main(String[] args){
		
		int a = 10;//十进制
		int b = 017;//八进制 
		int c = 0b101;//二进制 ob byte
		int d = 0x001D;//十六进制 ox hex
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
	}
}