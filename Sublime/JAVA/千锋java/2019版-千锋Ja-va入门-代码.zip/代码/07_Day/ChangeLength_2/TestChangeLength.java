public class TestChangeLength{
	public static void main(String[] args){
		//��ӡ1 2 3 4 5
		
		//int[] nums = {1,2,3,4,5};
		
		printArray();

	}
	
	public static void printArray(int... array){
		System.out.println(array.length);
		/*
		for(int i = 0 ; i < array.length ; i++){
			System.out.print(array[i]);
		}
		*/
	}
}