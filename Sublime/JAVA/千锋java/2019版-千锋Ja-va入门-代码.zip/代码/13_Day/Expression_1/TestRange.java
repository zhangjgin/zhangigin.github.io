package temp;

import p1.MyInterface;

public class TestRange{
	public static void main(String[] args){
		//System.out.println(MyClass.FIELD);
		
		System.out.println(MyInterface.FIELD);
		
		MyInterface.FIELD = "World";
	}
}